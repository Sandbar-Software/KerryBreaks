package com.example.z8365407.kerrybreaks;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class ActivityOptionsActivity extends Activity
{

    // GridLayout widgets:
    private Button mBeachesButton;
    private ImageView mBeachesImageView;
    private Button mHikeClimbButton;
    private ImageView mHikeClimbImageView;
    private Button mMarineButton;
    private ImageView mMarineImageView;
    private Button mGolfButton;
    private ImageView mGolfImageView;
    // Back button:
    private Button mBackButton;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_options);

        // Inflate view objects:
        mBeachesButton = (Button)findViewById(R.id.act_beaches_button);
        mBeachesImageView = (ImageView)findViewById(R.id.act_beaches_iview);
        mHikeClimbButton = (Button)findViewById(R.id.act_hikeclimb_button);
        mHikeClimbImageView = (ImageView)findViewById(R.id.act_hikeclimb_iview);
        mMarineButton = (Button)findViewById(R.id.act_marine_button);
        mMarineImageView = (ImageView)findViewById(R.id.act_marine_iview);
        mGolfButton = (Button)findViewById(R.id.act_golf_button);
        mGolfImageView = (ImageView)findViewById(R.id.act_golf_iview);
        // Activate buttons:
        /*mBeachesButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toAccomOptionsIntent = new Intent(v.getContext(), BeachesActivity.class);
                startActivity(toAccomOptionsIntent);
            }
        });
        mHikeClimbButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toActivityOptionsIntent = new Intent(v.getContext(), HikeClimbActivity.class);
                startActivity(toActivityOptionsIntent);
            }
        });
        mMarineButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toFoodDrinkOptionsIntent = new Intent(v.getContext(), MarineActivity.class);
                startActivity(toFoodDrinkOptionsIntent);
            }
        });
        mGolfButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toExperienceOptionsIntent = new Intent(v.getContext(), GolfActivity.class);
                startActivity(toExperienceOptionsIntent);
            }
        });*/
        // Activate back button:
        mBackButton = (Button)findViewById(R.id.activity_options_back_button);
        mBackButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent backHomeIntent = new Intent(v.getContext(), BreakOptionsActivity.class);
                startActivity(backHomeIntent);
            }
        });

    }


}
