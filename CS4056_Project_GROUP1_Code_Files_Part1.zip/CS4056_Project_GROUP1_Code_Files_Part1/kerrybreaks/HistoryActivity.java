package com.example.z8365407.kerrybreaks;

import android.app.Activity;
import android.media.MediaPlayer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

// Activity to play oral history of Barrow to user:

public class HistoryActivity extends Activity
{
    // MediaPlayer object for oral history feed :
    private MediaPlayer mMediaPlayer;
    // Audio player control buttons :
    private Button mPlayButton;
    private Button mStopButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Inflate & activate media player buttons :
        mPlayButton = (Button)findViewById(R.id.history_play_button);
        mPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Associate audio file with MediaPlayer instance :
                mMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.michaelosullivanbarrowhistory);
                // Play audio :
                mMediaPlayer.start();
            }
        });
        mStopButton = (Button)findViewById(R.id.history_stop_button);
        mStopButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // Stop & destroy MediaPlayer object : :
                onPause();
            }
        });
    }

    @Override
    public void onPause()
    {
        super.onPause();

        // Action when user pause audio output :
        if (mMediaPlayer != null)
        {
            /* Pausing the audio is not wise in Android as it would keep audio decoder hardware
              other system resources needed by other applications unavailable until release()
              method was activated -- which users may forget to do.
              So an aggressive stop() method is used which destroys the MediaPlayer instance.*/
            mMediaPlayer.stop(); // Stop playing the audio
            mMediaPlayer = null; // Destroy the media player object.
        }
    }


}
