package com.example.z8365407.kerrybreaks;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends Activity
{
    private TextView mTextView;
    private Button mProceedButton;
    private ImageView mEntryImage;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Inflate screen content:
        mEntryImage = (ImageView)findViewById(R.id.home_iv);
        mTextView = (TextView)findViewById(R.id.home_app_name_tv);
        mProceedButton = (Button)findViewById(R.id.home_proceed_button);
        // Activate mProceedButton :
        mProceedButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
              Intent toBreakOptionsIntent = new Intent(v.getContext(), BreakOptionsActivity.class);
              startActivity(toBreakOptionsIntent);
            }
        });


    }


}
