package com.example.z8365407.kerrybreaks;

import android.app.Activity;
import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Arrays;


public class HotelActivity extends Activity
{
    // Keys for extras inside toHotelIntent sent from HotelOptionsActivity :
    public static final String HOTEL_NAME = "com.example.z8365407.kerrybreaks.hotel_name";
    public static final String HOTEL_PHOTO_FILE = "com.example.z8365407.kerrybreaks.hotel_name";
    public static final String HOTEL_RATING = "com.example.z8365407.kerrybreaks.hotel_rating";
    public static final String HOTEL_PRICE = "com.example.z8365407.kerrybreaks.hotel_price";
    public static final String HOTEL_PHONE_NUMBER = "com.example.z8365407.kerrybreaks.hotel_phone";

    // Graphics attributes :
    private TextView mNameTextView;
    private ImageView mHotelImageView;
    private TextView mRatingTextView;
    private TextView mPriceTextView;
    private TextView mPhoneNumTextView;
    private Button mBackButton;
    // Hotel info string variables:
    private String hotelName, hotelPhotoFile, hotelRating, hotelPrice, hotelPhoneNum;
    private String[] hotelNames = {"White sands Hotel", "Banna Beach Hotel",
            "Mount Brandon Hotel", "Godley\'s Hotel"};
    private String[] hotelFiles = { "white_sands_hotel", "banna_beach_hotel",
                                    "mount_brandon_hotel", "west_end_hotel"};
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);
        // Inflate views of activity :
        mNameTextView = (TextView)findViewById(R.id.hotel_name);
        mHotelImageView = (ImageView)findViewById(R.id.hotel_iview);
        mRatingTextView = (TextView)findViewById(R.id.hotel_rating);
        mPriceTextView = (TextView)findViewById(R.id.hotel_price);
        mPhoneNumTextView = (TextView)findViewById(R.id.hotel_phone);
        // Find details of hotel :
        hotelName = getIntent().getStringExtra(HOTEL_NAME);
        // Find resource ID for that hotel name :
        for( i = 0; i < hotelNames.length && hotelNames[i] != hotelName; i++);
        if ( i < hotelNames.length)
        {
            hotelPhotoFile = hotelFiles[i];
        }
        else
        {
            System.out.println("No such hotel name in list.");
        }
        int drawableResourceId = this.getResources().getIdentifier(hotelPhotoFile, "drawable", getPackageName());
        // Use this resource id to dynamically set the image for the hotel :
        mHotelImageView.setImageResource(drawableResourceId);
        hotelRating = getIntent().getStringExtra(HOTEL_RATING);
        hotelPrice = getIntent().getStringExtra(HOTEL_PRICE);
        hotelPhoneNum = getIntent().getStringExtra(HOTEL_PHONE_NUMBER);
        // Add hotel info to HotelActivity display :
        mNameTextView.setText(hotelName);
        mHotelImageView.setImageResource(drawableResourceId);
        mRatingTextView.setText(hotelRating);
        mPriceTextView.setText(hotelPrice);
        mPhoneNumTextView.setText(hotelPhoneNum);
        mBackButton = (Button)findViewById(R.id.hotel_back_button);

        // Activate back button:
        mBackButton = (Button)findViewById(R.id.accom_options_back_button);
        mBackButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent backHomeIntent = new Intent(v.getContext(), HotelOptionsActivity.class);
                startActivity(backHomeIntent);
            }
        });
    }


}
