package com.example.z8365407.kerrybreaks;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;


public class BreakOptionsActivity extends Activity
{
    // GridLayout widgets:
    private Button mAccomButton;
    private ImageView mAccomImageView;
    private Button mActivitiesButton;
    private ImageView mActivitiesImageView;
    private Button mFoodDrinkButton;
    private ImageView mFoodDrinkImageView;
    private Button mExperienceButton;
    private ImageView mExperienceImageView;
    private Button mEventsButton;
    private ImageView mEventsImageView;
    // Back button:
    private Button mBackButton;
    // Oral history feed button :
    private Button mHistoryButton;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_break_options);
        // Inflate view objects:
        mAccomButton = (Button)findViewById(R.id.accom_button);
        mAccomImageView = (ImageView)findViewById(R.id.accom_iview);
        mActivitiesButton = (Button)findViewById(R.id.activities_button);
        mActivitiesImageView = (ImageView)findViewById(R.id.activities_iview);
        mFoodDrinkButton = (Button)findViewById(R.id.food_drink_button);
        mFoodDrinkImageView = (ImageView)findViewById(R.id.food_drink_iview);
        mExperienceButton = (Button)findViewById(R.id.experience_button);
        mAccomImageView = (ImageView)findViewById(R.id.experience_iview);
        mEventsButton = (Button)findViewById(R.id.events_button);
        mAccomImageView = (ImageView)findViewById(R.id.events_iview);
        // Activate buttons:
        mAccomButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toAccomOptionsIntent = new Intent(v.getContext(), AccomOptionsActivity.class);
                startActivity(toAccomOptionsIntent);
            }
        });
        mActivitiesButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toActivityOptionsIntent = new Intent(v.getContext(), ActivityOptionsActivity.class);
                startActivity(toActivityOptionsIntent);
            }
        });
        mFoodDrinkButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toFoodDrinkOptionsIntent = new Intent(v.getContext(), FoodDrinkOptionsActivity.class);
                startActivity(toFoodDrinkOptionsIntent);
            }
        });
        mExperienceButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toExperienceOptionsIntent = new Intent(v.getContext(), ExperienceOptionsActivity.class);
                startActivity(toExperienceOptionsIntent);
            }
        });
        mEventsButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toEventOptionsIntent = new Intent(v.getContext(), EventOptionsActivity.class);
                startActivity(toEventOptionsIntent);
            }
        });
        // Activate back button:
        mBackButton = (Button)findViewById(R.id.break_options_back_button);
        mBackButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent backHomeIntent = new Intent(v.getContext(), MainActivity.class);
                startActivity(backHomeIntent);
            }
        });
        // Activate history button:
        mHistoryButton = (Button)findViewById(R.id.break_options_history_button);
        mHistoryButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toHistoryIntent = new Intent(v.getContext(), HistoryActivity.class);
                startActivity(toHistoryIntent);
            }
        });
    }


}
