package com.example.z8365407.kerrybreaks;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class HotelOptionsActivity extends Activity
{

    // GridLayout widgets:
    private Button mHotel1Button;
    private ImageView mHotel1ImageView;
    private Button mHotel2Button;
    private ImageView mHotel2ImageView;
    private Button mHotel3Button;
    private ImageView mHotel3ImageView;
    private Button mHotel4Button;
    private ImageView mHotel4ImageView;
    // Back button:
    private Button mBackButton;
    // Hotel attributes :
    private String hotelName;
    private String hotelPhotoFile;
    private String hotelRating;
    private String hotelPrice;
    private String hotelPhoneNum;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotels_options);

        // Inflate view objects and add data obtained from string resources file :
        mHotel1Button = (Button)findViewById(R.id.hotel_option1_button);
        mHotel1Button.setText(getResources().getString(R.string.hotel1));
        mHotel1ImageView = (ImageView)findViewById(R.id.hotel_option1_iview);
        mHotel2Button = (Button)findViewById(R.id.hotel_option2_button);
        mHotel2Button.setText(getResources().getString(R.string.hotel2));
        mHotel2ImageView = (ImageView)findViewById(R.id.hotel_option2_iview);
        mHotel3Button = (Button)findViewById(R.id.hotel_option3_button);
        mHotel3Button.setText(getResources().getString(R.string.hotel3));
        mHotel3ImageView = (ImageView)findViewById(R.id.hotel_option3_iview);
        mHotel4Button = (Button)findViewById(R.id.hotel_option4_button);
        mHotel4Button.setText(getResources().getString(R.string.hotel4));
        mHotel4ImageView = (ImageView)findViewById(R.id.hotel_option4_iview);
        // Activate buttons:
        mHotel1Button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toHotelIntent = new Intent(v.getContext(), HotelActivity.class);
                // Get info on this hotel from string resources :
                hotelName = getResources().getString(R.string.hotel1);
                hotelPhotoFile = "@drawable/" + getResources().getString(R.string.hotel1_photofile);
                hotelRating = getResources().getString(R.string.hotel1_rating);
                hotelPrice= getResources().getString(R.string.hotel1_price);
                hotelPhoneNum = getResources().getString(R.string.hotel1_phone);
                // Attach these strings as extras to the Intent call on HotelActivity :
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelName);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelRating);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPrice);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPhoneNum);
                // Start HotelActivity :
                startActivity(toHotelIntent);
            }
        });
        mHotel2Button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toHotelIntent = new Intent(v.getContext(), HotelActivity.class);
                // Get info on this hotel from string resources :
                hotelName = getResources().getString(R.string.hotel2);
                hotelPhotoFile = "@drawable/" + getResources().getString(R.string.hotel2_photofile);
                hotelRating = getResources().getString(R.string.hotel2_rating);
                hotelPrice= getResources().getString(R.string.hotel2_price);
                hotelPhoneNum = getResources().getString(R.string.hotel2_phone);
                // Attach these strings as extras to the Intent call on HotelActivity :
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelName.toString());
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelRating);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPrice.toString());
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPhoneNum);
                // Start HotelActivity :
                startActivity(toHotelIntent);
            }
        });
        mHotel3Button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toHotelIntent = new Intent(v.getContext(), HotelActivity.class);
                // Get info on this hotel from string resources :
                hotelName = getResources().getString(R.string.hotel3);
                hotelPhotoFile = "@drawable/" + getResources().getString(R.string.hotel3_photofile);
                hotelRating = getResources().getString(R.string.hotel3_rating);
                hotelPrice= getResources().getString(R.string.hotel3_price);
                hotelPhoneNum = getResources().getString(R.string.hotel3_phone);
                // Attach these strings as extras to the Intent call on HotelActivity :
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelName);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelRating);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPrice);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPhoneNum);
                // Start HotelActivity :
                startActivity(toHotelIntent);
            }
        });
        mHotel4Button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toHotelIntent = new Intent(v.getContext(), HotelActivity.class);
                // Get info on this hotel from string resources :
                hotelName = getResources().getString(R.string.hotel4);
                hotelPhotoFile = getResources().getString(R.string.hotel1_photofile);
                hotelRating = getResources().getString(R.string.hotel4_rating);
                hotelPrice= getResources().getString(R.string.hotel4_price);
                hotelPhoneNum = getResources().getString(R.string.hotel4_phone);
                // Attach these strings as extras to the Intent call on HotelActivity :
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelName);
                toHotelIntent.putExtra(HotelActivity.HOTEL_PHOTO_FILE, hotelPhotoFile);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelRating);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPrice);
                toHotelIntent.putExtra(HotelActivity.HOTEL_NAME, hotelPhoneNum);
                // Start HotelActivity :
                startActivity(toHotelIntent);
            }
        });
        // Activate back button:
        mBackButton = (Button)findViewById(R.id.hotel_options_back_button);
        mBackButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent backHomeIntent = new Intent(v.getContext(), AccomOptionsActivity.class);
                startActivity(backHomeIntent);
            }
        });

    }


}
