package com.example.z8365407.kerrybreaks;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class AccomOptionsActivity extends Activity
{

    // GridLayout widgets:
    private Button mHotelsButton;
    private ImageView mHotelsImageView;
    private Button mGuesthousesButton;
    private ImageView mGuesthousesImageView;
    private Button mCampingButton;
    private ImageView mCampingImageView;
    private Button mRentedsButton;
    private ImageView mRentedsImageView;
    // Back button:
    private Button mBackButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accom_options);

        // Inflate view objects:
        mHotelsButton = (Button)findViewById(R.id.accom_hotels_button);
        mHotelsImageView = (ImageView)findViewById(R.id.accom_hotels_iview);
        mGuesthousesButton = (Button)findViewById(R.id.accom_guesthouses_button);
        mGuesthousesImageView = (ImageView)findViewById(R.id.accom_guesthouses_iview);
        mCampingButton = (Button)findViewById(R.id.accom_camping_button);
        mCampingImageView = (ImageView)findViewById(R.id.accom_camping_iview);
        mRentedsButton = (Button)findViewById(R.id.accom_renteds_button);
        mRentedsImageView = (ImageView)findViewById(R.id.accom_renteds_iview);
        // Activate buttons:
        mHotelsButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toAccomOptionsIntent = new Intent(v.getContext(), HotelOptionsActivity.class);
                startActivity(toAccomOptionsIntent);
            }
        });
        mGuesthousesButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toActivityOptionsIntent = new Intent(v.getContext(), HotelOptionsActivity.class);
                startActivity(toActivityOptionsIntent);
            }
        });
        mCampingButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toFoodDrinkOptionsIntent = new Intent(v.getContext(), HotelOptionsActivity.class);
                startActivity(toFoodDrinkOptionsIntent);
            }
        });
        mRentedsButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent toExperienceOptionsIntent = new Intent(v.getContext(), HotelOptionsActivity.class);
                startActivity(toExperienceOptionsIntent);
            }
        });
        // Activate back button:
        mBackButton = (Button)findViewById(R.id.accom_options_back_button);
        mBackButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent backHomeIntent = new Intent(v.getContext(), BreakOptionsActivity.class);
                startActivity(backHomeIntent);
            }
        });

    }


}
